package com.lgedu.binarytree;

/**
 * 树的节点
 */
public class TreeNode {
    //值
    int data;
    //左孩子
    TreeNode leftChild;
    //右孩子
    TreeNode rightChild;

    public TreeNode(int data) {
        this.data = data;
    }
}
