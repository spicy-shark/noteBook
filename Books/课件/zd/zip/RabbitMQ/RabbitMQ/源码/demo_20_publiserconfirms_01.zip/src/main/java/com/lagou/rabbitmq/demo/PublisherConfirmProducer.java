package com.lagou.rabbitmq.demo;

public class PublisherConfirmProducer {

    public static void main(String[] args) {
        connecti



    }

}
