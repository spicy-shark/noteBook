package com.lagou.rabbitmq.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo19DelayedExchangeApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo19DelayedExchangeApplication.class, args);
    }

}
