package com.lagou.rabbitmq.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo19DelayedExchangeApplicationTests {

    @Test
    void contextLoads() {
    }

}
